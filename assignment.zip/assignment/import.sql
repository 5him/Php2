CREATE DATABASE /*!32312 IF NOT EXISTS*/ `news` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_uca1400_ai_ci */;

USE `news`;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoryId` varchar(45) DEFAULT NULL,
  `title` varchar(45) DEFAULT NULL,
  `description` varchar(4500) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (4,'1','Man wins prize',' Mauris sed eros mollis elit suscipit blandit. Suspendisse tristique vestibulum tortor eu aliquet. Curabitur a lacus vestibulum, efficitur sapien nec, ultricies sapien. Nam consequat cursus fermentum. Nullam sed facilisis justo. Donec non placerat urna. Cras feugiat vel lacus nec pellentesque. Aenean sed arcu ex. Duis elit ligula, tincidunt quis porta sed, iaculis ac sapien. Integer congue accumsan dui sit amet mattis. Sed at ipsum ac est blandit hendrerit eget quis orci. Aenean at porta turpis. Aliquam sit amet interdum mi. Praesent nec nisl id tortor bibendum commodo non sed nunc. Cras eu metus placerat, laoreet lectus a, lobortis turpis.\r\n\r\n','2024-11-26 19:31:03'),(6,'3','Northampton football team wins championship','Integer tempus commodo quam, vitae vulputate ipsum porttitor sed. Vivamus hendrerit sapien eu placerat lacinia. Aliquam malesuada scelerisque ultricies. Proin vitae pellentesque ligula. Aliquam feugiat, ante fermentum scelerisque iaculis, purus mi ornare tortor, condimentum accumsan dolor mauris sed dui. Ut sit amet orci tincidunt, scelerisque nibh nec, dictum justo. In tempor lectus sed vulputate lobortis. Fusce quam lacus, feugiat in placerat eu, consectetur eget felis. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur semper tortor et tellus tempor, non rhoncus est varius. Sed elementum tellus non arcu dictum convallis. In non posuere quam, at interdum ligula. Nullam vestibulum arcu et pulvinar ornare. Ut varius arcu sit amet turpis rutrum, vitae ultricies est porta. ','2024-11-26 20:51:29'),(7,'2','Northampton Christmas Lights Turned On',' Mauris sed eros mollis elit suscipit blandit. Suspendisse tristique vestibulum tortor eu aliquet. Curabitur a lacus vestibulum, efficitur sapien nec, ultricies sapien. Nam consequat cursus fermentum. Nullam sed facilisis justo. Donec non placerat urna. Cras feugiat vel lacus nec pellentesque. Aenean sed arcu ex. Duis elit ligula, tincidunt quis porta sed, iaculis ac sapien. Integer congue accumsan dui sit amet mattis. Sed at ipsum ac est blandit hendrerit eget quis orci. Aenean at porta turpis. Aliquam sit amet interdum mi. Praesent nec nisl id tortor bibendum commodo non sed nunc. Cras eu metus placerat, laoreet lectus a, lobortis turpis. ','2024-11-26 20:51:51');
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Local News'),(2,'Local Events'),(3,'Sport');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumping routines for database 'news'
--

